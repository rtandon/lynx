VitaVim
=======

Your Daily dose of vim essentials.

To install Just do :

    git clone git://github.com/confessin/vitavim vitavim/
    cd vitavim
    ./install.sh


Ands you are doens. Enjoy !! *Derp*


FAQ:
=======

Not working:
    
    You can just back up your .vimrc and .vim(if exists) and remove them (or unlink them), follow the installation steps and copy your .vimrc into local.vimrc
